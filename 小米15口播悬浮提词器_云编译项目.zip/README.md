# 口播悬浮提词器（Android 项目源码）

这是第一版 Android Studio 项目，目标是在小米手机自带相机前置拍摄时显示悬浮提词窗口。

## 当前功能
- 输入/粘贴口播文案
- 悬浮窗显示文案，可拖动位置
- 自动滚动
- 慢/快调节
- 暂停/继续、重头、关闭
- 前台通知维持服务运行

## 如何构建 APK
1. 在电脑安装 Android Studio（建议使用较新版本）。
2. 解压项目，Android Studio 选择 Open，打开 `KouboTeleprompter` 文件夹。
3. 等待 Gradle Sync 完成。
4. 选择 Build > Build Bundle(s) / APK(s) > Build APK(s)。
5. 构建完成后，点击提示中的 locate，即可找到 APK。

## 小米手机首次使用
1. 安装 APK。
2. 打开“口播悬浮提词器”，粘贴文案。
3. 点击“开启悬浮提词”，按提示允许“显示在其他应用上层”。
4. 返回应用，再次点击开启。
5. 切换到手机自带相机，使用前置摄像头。
6. 如悬浮窗被系统清理，可在系统设置的应用管理中，按需允许后台运行/自启动，并关闭该应用的省电限制。

## 当前版本说明
这是可继续编译和修改的源码项目，不是已经在小米15真机上验证过的 APK。不同 HyperOS 版本的悬浮窗和后台权限菜单名称可能略有差异。Android 14/15 对前台服务也有系统限制，首次运行时请按系统提示授权。

## GitHub Actions 云端编译（手机操作）
项目已包含 `.github/workflows/android.yml`。把项目文件放入 GitHub 仓库根目录并推送到 `main` 后，Actions 会自动构建 APK。也可在 Actions 页面手动运行 `Build Android APK`。构建成功后，在该次运行页面底部的 Artifacts 下载 `koubo-teleprompter-debug-apk`，解压后安装 `app-debug.apk`。
