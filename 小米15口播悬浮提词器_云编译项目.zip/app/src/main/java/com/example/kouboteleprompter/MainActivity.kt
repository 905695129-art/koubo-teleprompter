package com.example.kouboteleprompter

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var script: EditText
    private val prefs by lazy { getSharedPreferences("teleprompter", MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(22, 24, 22, 22)
        }
        val title = TextView(this).apply {
            text = "口播悬浮提词器"
            textSize = 24f
            gravity = Gravity.CENTER
        }
        val desc = TextView(this).apply {
            text = "粘贴口播稿，开启悬浮窗后，再打开手机自带相机。"
            textSize = 14f
            setPadding(0, 12, 0, 12)
        }
        script = EditText(this).apply {
            hint = "在这里粘贴你的口播文案……"
            gravity = Gravity.TOP or Gravity.START
            textSize = 18f
            minLines = 8
            setText(prefs.getString("script", "大家好，今天我们来聊一个话题。\n\n先别急着下结论，我们先看清楚问题背后的原因。"))
        }
        val start = Button(this).apply {
            text = "开启悬浮提词"
            setOnClickListener { startTeleprompter() }
        }
        val tip = TextView(this).apply {
            text = "提示：首次使用需要允许“显示在其他应用上层”。小米系统可能还需要在应用信息中允许后台运行或自启动。"
            textSize = 13f
            setPadding(0, 14, 0, 0)
        }

        root.addView(title, LinearLayout.LayoutParams(-1, -2))
        root.addView(desc)
        root.addView(script, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(start, LinearLayout.LayoutParams(-1, -2))
        root.addView(tip)
        setContentView(root)
    }

    private fun startTeleprompter() {
        val text = script.text.toString().trim()
        if (text.isEmpty()) {
            Toast.makeText(this, "请先输入口播文案", Toast.LENGTH_SHORT).show()
            return
        }
        prefs.edit().putString("script", text).apply()

        if (!Settings.canDrawOverlays(this)) {
            val intent = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            startActivity(intent)
            Toast.makeText(this, "请在设置页面允许悬浮窗权限，然后返回本应用再次点击开启", Toast.LENGTH_LONG).show()
            return
        }

        val serviceIntent = Intent(this, TeleprompterService::class.java).putExtra("script", text)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(serviceIntent)
        else startService(serviceIntent)
        Toast.makeText(this, "悬浮提词已开启，可切换到手机自带相机", Toast.LENGTH_LONG).show()
    }

    override fun onPause() {
        super.onPause()
        if (::script.isInitialized) prefs.edit().putString("script", script.text.toString()).apply()
    }
}
