package com.example.kouboteleprompter

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class TeleprompterService : Service() {
    private lateinit var windowManager: WindowManager
    private var overlay: View? = null
    private var scrollView: ScrollView? = null
    private var running = true
    private var speed = 2
    private val handler = Handler(Looper.getMainLooper())
    private val tick = object : Runnable {
        override fun run() {
            if (running) scrollView?.smoothScrollBy(0, speed)
            handler.postDelayed(this, 45)
        }
    }

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        startForeground(1001, buildNotification())
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val script = intent?.getStringExtra("script") ?: "请先返回提词器输入文案。"
        showOverlay(script)
        handler.removeCallbacks(tick)
        handler.post(tick)
        return START_STICKY
    }

    private fun showOverlay(script: String) {
        overlay?.let { try { windowManager.removeView(it) } catch (_: Exception) {} }
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(12, 8, 12, 8)
            setBackgroundColor(0xDD151515.toInt())
        }

        val header = TextView(this).apply {
            text = "口播提词  ·  拖动此处移动"
            textSize = 12f
            setTextColor(Color.WHITE)
            setPadding(4, 2, 4, 8)
        }
        val scroller = ScrollView(this).apply {
            isFillViewport = false
            setBackgroundColor(0x55222222)
        }
        val content = TextView(this).apply {
            text = script + "\n\n" + script
            textSize = 22f
            setTextColor(Color.WHITE)
            setLineSpacing(7f, 1.0f)
            setPadding(8, 8, 8, 28)
        }
        scroller.addView(content)
        scrollView = scroller

        val controls = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        fun button(label: String, action: (Button) -> Unit): Button =
            Button(this).apply {
                text = label
                textSize = 11f
                setPadding(2, 0, 2, 0)
                setOnClickListener { action(this) }
            }
        controls.addView(button("慢", { _ -> speed = (speed - 1).coerceAtLeast(1) }), LinearLayout.LayoutParams(0, 42, 1f))
        controls.addView(button("快", { _ -> speed = (speed + 1).coerceAtMost(12) }), LinearLayout.LayoutParams(0, 42, 1f))
        controls.addView(button(if (running) "暂停" else "继续", { b ->
            running = !running
            b.text = if (running) "暂停" else "继续"
        }), LinearLayout.LayoutParams(0, 42, 1f))
        controls.addView(button("重头", { _ ->
            scroller.post { scroller.scrollTo(0, 0) }
            running = true
        }), LinearLayout.LayoutParams(0, 42, 1f))
        controls.addView(button("关闭", { _ -> stopSelf() }), LinearLayout.LayoutParams(0, 42, 1f))

        panel.addView(header)
        panel.addView(scroller, LinearLayout.LayoutParams(-1, 150))
        panel.addView(controls)

        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE

        val params = WindowManager.LayoutParams(
            (resources.displayMetrics.widthPixels * 0.88f).toInt(),
            WindowManager.LayoutParams.WRAP_CONTENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            y = 110
        }

        var initialX = 0
        var initialY = 0
        var downX = 0f
        var downY = 0f
        header.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    initialX = params.x; initialY = params.y
                    downX = event.rawX; downY = event.rawY
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    params.x = initialX + (event.rawX - downX).toInt()
                    params.y = initialY + (event.rawY - downY).toInt()
                    try { windowManager.updateViewLayout(panel, params) } catch (_: Exception) {}
                    true
                }
                else -> true
            }
        }

        overlay = panel
        try { windowManager.addView(panel, params) } catch (_: Exception) { stopSelf() }
    }

    override fun onDestroy() {
        handler.removeCallbacks(tick)
        overlay?.let { try { windowManager.removeView(it) } catch (_: Exception) {} }
        overlay = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel("teleprompter", "悬浮提词器", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun buildNotification(): Notification {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Notification.Builder(this, "teleprompter")
                .setContentTitle("口播悬浮提词器正在运行")
                .setContentText("切换到手机自带相机即可开始口播")
                .setSmallIcon(android.R.drawable.ic_media_play)
                .setOngoing(true)
                .build()
        } else {
            @Suppress("DEPRECATION")
            Notification.Builder(this)
                .setContentTitle("口播悬浮提词器正在运行")
                .setSmallIcon(android.R.drawable.ic_media_play)
                .build()
        }
    }
}
